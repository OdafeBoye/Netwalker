document.getElementById('hamburgerIcon').addEventListener('click', function() {
  const sideMenu = document.querySelector('.Sidemenu');
  sideMenu.classList.toggle('active');
});

// Close the side menu when clicking outside of it
document.addEventListener('click', function(event) {
  const sideMenu = document.querySelector('.Sidemenu');
  const hamburgerIcon = document.getElementById('hamburgerIcon');
  
  // Check if the click is outside the side menu and the hamburger icon
  if (!sideMenu.contains(event.target) && !hamburgerIcon.contains(event.target)) {
      sideMenu.classList.remove('active');
  }
});
